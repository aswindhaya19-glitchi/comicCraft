from .exporters import save_pdf
from .gemini_flash import generate_outline
from .gemini_pro import generate_story
from .image_generator import generate_image
from .layout_builder import build_comic_layout
from .models import PromptRequest


def create_comic(request: PromptRequest) -> dict:
    outline = generate_outline(
        request.story_prompt,
        request.character_name,
        request.setting,
        request.tone,
        request.art_style,
    )
    story = generate_story(outline, request.character_name, request.tone)
    image_paths = [generate_image(panel.image_prompt, panel.panel_number) for panel in outline.panels]
    layout = build_comic_layout(outline, story, image_paths)
    pdf_path = save_pdf(layout, title=f"{request.character_name}_comic")
    return {"panels": layout, "pdf_path": pdf_path}
