from .models import ComicOutline, ComicStory


def build_comic_layout(outline: ComicOutline, story: ComicStory, image_paths: list[str]) -> list[dict]:
    stories = {panel.panel_number: panel for panel in story.panels}
    layout = []
    for index, panel in enumerate(sorted(outline.panels, key=lambda p: p.panel_number)):
        script = stories.get(panel.panel_number)
        if script is None:
            raise ValueError(f"Missing story for panel {panel.panel_number}")
        layout.append(
            {
                "panel_number": panel.panel_number,
                "title": panel.title,
                "image_path": image_paths[index],
                "scene_description": panel.scene_description,
                "image_prompt": panel.image_prompt,
                "caption": script.caption,
                "narration": script.narration,
                "dialogue": script.dialogue,
            }
        )
    return layout
