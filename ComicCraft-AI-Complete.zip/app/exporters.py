import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from fpdf import FPDF

from .config import get_settings


def _local_image_path(image_path: str) -> Path:
    settings = get_settings()
    parsed = urlparse(image_path)
    relative = parsed.path.removeprefix("/static/")
    candidate = settings.static_dir / relative
    candidate = candidate.resolve()
    static_root = settings.static_dir.resolve()
    if static_root not in candidate.parents:
        raise ValueError("Invalid image path")
    return candidate


def _pdf_text(value: str) -> str:
    """Convert arbitrary AI text into text supported by FPDF core fonts."""
    return str(value).encode("latin-1", "replace").decode("latin-1")


def _safe_filename(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "_", value).strip("_")[:60] or "comic"


def save_pdf(layout: list[dict], title: str = "ComicCraft Comic") -> str:
    settings = get_settings()
    export_dir = settings.static_dir / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)

    filename = f"{_safe_filename(title)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    pdf_path = export_dir / filename

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 10, _pdf_text(f"Panel {panel['panel_number']}: {panel['title']}"))
        pdf.ln(2)

        image_path = _local_image_path(panel["image_path"])
        if image_path.exists():
            pdf.image(str(image_path), x=30, y=38, w=150)
            pdf.set_y(145)
        else:
            pdf.set_font("Helvetica", "I", 11)
            pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, "Illustration unavailable.")

        pdf.set_font("Helvetica", "I", 11)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, _pdf_text(panel["scene_description"]))
        pdf.ln(2)
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, "Caption")
        pdf.set_font("Helvetica", "", 11)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, _pdf_text(panel["caption"]))
        pdf.ln(1)
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, "Narration")
        pdf.set_font("Helvetica", "", 11)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, _pdf_text(panel["narration"]))
        pdf.ln(1)
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, "Dialogue")
        pdf.set_font("Helvetica", "", 11)
        pdf.set_x(pdf.l_margin); pdf.multi_cell(0, 7, _pdf_text(panel["dialogue"]))

    pdf.output(str(pdf_path))
    return f"/static/exports/{pdf_path.name}"
