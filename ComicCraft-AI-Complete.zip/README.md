# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI + Jinja2 web app that turns a user's idea into a five-panel comic. The pipeline follows the supplied project document: structured outline → comic script → panel illustrations → layout → PDF export.

The original document uses Gemini 1.5 and `google-generativeai`. This implementation uses Google's newer `google-genai` SDK and environment-configurable Gemini model IDs so the project can be maintained as model availability changes.

## Features

- Five-panel structured comic outline
- Gemini-generated narration, captions and dialogue
- Local Stable Diffusion through Hugging Face Diffusers
- Optional hosted Hugging Face image generation
- Demo/placeholder mode for testing the entire app without API credentials
- Jinja2 frontend
- JSON API endpoint
- Image test endpoint
- Multi-page PDF export
- Basic automated tests
- Environment-based configuration

## Project structure

```text
comiccraft/
├── app/
│   ├── __init__.py
│   ├── __main__.py
│   ├── config.py
│   ├── exporters.py
│   ├── gemini_flash.py
│   ├── gemini_pro.py
│   ├── image_generator.py
│   ├── layout_builder.py
│   ├── main.py
│   ├── models.py
│   ├── routes.py
│   └── services.py
├── static/
│   ├── css/style.css
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── tests/test_app.py
├── .env.example
├── .gitignore
├── pytest.ini
└── requirements.txt
```

## Recommended Python version

Use Python 3.11 on Windows for the easiest Diffusers/PyTorch setup.

## VS Code setup — Windows

Open the project folder in VS Code.

### 1. Create a virtual environment

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate.bat
```

### 2. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Configure environment variables

Copy `.env.example` to `.env`.

For a real AI run, put your Gemini API key in `.env`:

```env
GEMINI_API_KEY=your_key_here
DEMO_MODE=false
IMAGE_PROVIDER=diffusers
```

The Gemini SDK reads the API key supplied to `genai.Client`. Structured output is requested with a Pydantic schema.

### 4. First test the application without AI credentials

Use this configuration first:

```env
DEMO_MODE=true
IMAGE_PROVIDER=placeholder
```

Then run:

```powershell
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000 — web UI
- http://127.0.0.1:8000/docs — Swagger API docs
- http://127.0.0.1:8000/health — health check

Generate a demo comic. It creates placeholder panel images and a real PDF, so you can verify the whole application flow before installing/configuring image AI.

## Real Gemini + local Stable Diffusion

Change `.env`:

```env
GEMINI_API_KEY=your_key_here
DEMO_MODE=false
IMAGE_PROVIDER=diffusers
GEMINI_FLASH_MODEL=gemini-3.8-flash
GEMINI_PRO_MODEL=gemini-3.1-pro-preview
```

Then restart Uvicorn.

The first Diffusers generation downloads the configured image model. This can be large and CPU generation can be slow. A CUDA-capable NVIDIA GPU is strongly recommended for practical local image generation.

If your Gemini account does not expose a configured model, change the model variables to a model available to your account. For example, the project accepts `gemini-2.5-flash` and `gemini-2.5-pro` through environment variables.

## Hosted Hugging Face image generation option

If local Diffusers is too heavy for the computer, use:

```env
IMAGE_PROVIDER=huggingface
HF_API_KEY=your_huggingface_token
HF_IMAGE_MODEL=stable-diffusion-v1-5/stable-diffusion-v1-5
```

The story still uses Gemini; only image generation moves to Hugging Face's hosted inference service.

## API example

`POST /generate-comic/json`

```json
{
  "story_prompt": "A brave fox explores an enchanted forest.",
  "character_name": "Finn",
  "setting": "Forest",
  "tone": "Dramatic",
  "art_style": "Comic book"
}
```

The response contains `success`, five `panels`, and a `pdf_path`.

## Image test endpoint

Open:

```text
http://127.0.0.1:8000/test-image?prompt=a%20brave%20fox%20in%20an%20enchanted%20forest
```

This is useful for debugging image generation separately from the full comic workflow.

## Run tests

With the virtual environment active:

```powershell
pytest -q
```

The tests force demo/placeholder mode so they do not call external AI services.

## Common problems

### `GEMINI_API_KEY is not configured`

Add the key to `.env`, or temporarily set `DEMO_MODE=true`.

### Diffusers is very slow

This is expected on CPU. Use an NVIDIA CUDA setup or switch to `IMAGE_PROVIDER=huggingface`.

### Out of memory while loading the image model

Use hosted Hugging Face inference, or configure a smaller/current image model suitable for your hardware. The code keeps image dimensions and inference steps configurable in `.env`.

### Windows PyTorch/Diffusers installation issues

Use Python 3.11 and a fresh `.venv`. For NVIDIA systems, install the PyTorch build recommended for your CUDA version before installing/using Diffusers if necessary.

## Production notes

For deployment, add authentication, rate limiting, job queues/background workers, persistent storage, cleanup policies for generated images, request size limits, and secure secret management. The current project is designed for local development and demonstration, matching the scope of the supplied documentation.
