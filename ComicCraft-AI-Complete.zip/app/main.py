from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .config import get_settings
from .routes import router


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    (settings.static_dir / "panels").mkdir(parents=True, exist_ok=True)
    (settings.static_dir / "exports").mkdir(parents=True, exist_ok=True)
    yield


settings = get_settings()
app = FastAPI(
    title=settings.app_name,
    description="Generate five-panel AI comics with Gemini and Diffusers.",
    version="1.0.0",
    lifespan=lifespan,
)
app.mount("/static", StaticFiles(directory=str(settings.static_dir)), name="static")
app.include_router(router)


@app.get("/health")
async def health():
    return {"status": "ok", "demo_mode": settings.demo_mode, "image_provider": settings.image_provider}
