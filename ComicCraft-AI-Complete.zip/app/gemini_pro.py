
from .config import get_settings
from .models import ComicOutline, ComicStory


def _demo_story(outline: ComicOutline, character_name: str) -> ComicStory:
    return ComicStory(
        panels=[
            {
                "panel_number": p.panel_number,
                "caption": f"Panel {p.panel_number}: {p.title}",
                "narration": p.scene_description,
                "dialogue": f"{character_name}: We have to keep going!",
            }
            for p in outline.panels
        ]
    )


def generate_story(outline: ComicOutline, character_name: str, tone: str) -> ComicStory:
    settings = get_settings()
    if settings.demo_mode:
        return _demo_story(outline, character_name)
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env or enable DEMO_MODE=true.")

    from google import genai
    client = genai.Client(api_key=settings.gemini_api_key)
    outline_json = outline.model_dump_json(indent=2)
    prompt = f"""
Expand this five-panel outline into a polished comic script.
Main character: {character_name}
Tone: {tone}
Outline:
{outline_json}

Requirements:
- Return exactly five panel story objects matching panel numbers 1-5.
- Each panel needs a short caption, vivid narration, and natural dialogue.
- Keep continuity with the outline.
- Dialogue should sound like a comic, not an essay.
- Keep each field concise enough to fit beneath a comic illustration.
"""
    response = client.models.generate_content(
        model=settings.gemini_pro_model,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": ComicStory,
            "temperature": 0.9,
        },
    )
    if getattr(response, "parsed", None):
        return response.parsed
    if not response.text:
        raise RuntimeError("Gemini returned an empty story response.")
    return ComicStory.model_validate_json(response.text)
