from pydantic import BaseModel

from .config import get_settings
from .models import ComicOutline


def _demo_outline(story_prompt: str, character_name: str, setting: str, tone: str, art_style: str) -> ComicOutline:
    return ComicOutline(
        panels=[
            {
                "panel_number": 1,
                "title": "The Beginning",
                "scene_description": f"{character_name} arrives at {setting}, ready for an unexpected adventure.",
                "image_prompt": f"{art_style} comic panel, {character_name} entering {setting}, {tone} mood, cinematic composition, expressive character, clean line art",
            },
            {
                "panel_number": 2,
                "title": "A Strange Discovery",
                "scene_description": f"A mysterious clue appears and changes the direction of {character_name}'s journey.",
                "image_prompt": f"{art_style} comic panel, {character_name} discovering a mysterious clue in {setting}, {tone} mood, dynamic lighting, expressive face",
            },
            {
                "panel_number": 3,
                "title": "The Challenge",
                "scene_description": f"The central challenge of the story becomes impossible to ignore.",
                "image_prompt": f"{art_style} comic panel, {character_name} facing the main challenge in {setting}, {tone} mood, dramatic action, strong perspective",
            },
            {
                "panel_number": 4,
                "title": "The Turning Point",
                "scene_description": f"{character_name} makes a brave choice that changes everything.",
                "image_prompt": f"{art_style} comic panel, heroic turning point for {character_name} in {setting}, {tone} mood, emotional cinematic scene",
            },
            {
                "panel_number": 5,
                "title": "A New Beginning",
                "scene_description": f"The adventure reaches a satisfying ending while leaving a hint of what could come next.",
                "image_prompt": f"{art_style} comic panel, {character_name} after the adventure in {setting}, hopeful ending, {tone} mood, beautiful composition",
            },
        ]
    )


def generate_outline(story_prompt: str, character_name: str, setting: str, tone: str, art_style: str) -> ComicOutline:
    settings = get_settings()
    if settings.demo_mode:
        return _demo_outline(story_prompt, character_name, setting, tone, art_style)
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env or enable DEMO_MODE=true.")

    from google import genai
    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f"""
Create exactly five sequential comic panels from this idea.
Story prompt: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Requirements:
- Preserve the user's story idea.
- Make the five panels form one coherent beginning, development, conflict, turning point, and ending.
- Keep the same main character and setting across all panels.
- image_prompt must describe only visual content and must be suitable for a text-to-image model.
- Do not put speech text, captions, logos, watermarks, or UI text inside image_prompt.
- Return exactly five panels with panel numbers 1 through 5.
"""
    response = client.models.generate_content(
        model=settings.gemini_flash_model,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": ComicOutline,
            "temperature": 0.8,
        },
    )
    if getattr(response, "parsed", None):
        return response.parsed
    if not response.text:
        raise RuntimeError("Gemini returned an empty outline response.")
    return ComicOutline.model_validate_json(response.text)
