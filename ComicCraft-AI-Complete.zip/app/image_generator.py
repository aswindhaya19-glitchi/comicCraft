import re
from datetime import datetime
from pathlib import Path
from threading import Lock

from PIL import Image, ImageDraw, ImageFont

from .config import get_settings

_PIPELINE = None
_PIPELINE_LOCK = Lock()


def _safe_name(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "_", value).strip("_")
    return value[:80] or "panel"


def _output_path(panel_number: int, prompt: str) -> Path:
    settings = get_settings()
    settings.static_dir.joinpath("panels").mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return settings.static_dir / "panels" / f"panel_{panel_number}_{_safe_name(prompt)[:45]}_{stamp}.png"


def _placeholder_image(prompt: str, panel_number: int, path: Path) -> str:
    image = Image.new("RGB", (768, 512), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((8, 8, 760, 504), outline="black", width=6)
    draw.text((32, 28), f"COMICCRAFT • PANEL {panel_number}", fill="black")
    words = prompt.split()
    lines = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) > 55:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    draw.multiline_text((32, 90), "\n".join(lines[:10]), fill="black", spacing=10)
    image.save(path, "PNG")
    return f"/static/panels/{path.name}"


def _generate_diffusers(prompt: str, path: Path) -> None:
    global _PIPELINE
    import torch
    from diffusers import DiffusionPipeline

    settings = get_settings()
    with _PIPELINE_LOCK:
        if _PIPELINE is None:
            dtype = torch.float16 if torch.cuda.is_available() else torch.float32
            _PIPELINE = DiffusionPipeline.from_pretrained(
                settings.hf_image_model,
                torch_dtype=dtype,
                use_safetensors=True,
            )
            if torch.cuda.is_available():
                _PIPELINE = _PIPELINE.to("cuda")
            else:
                _PIPELINE = _PIPELINE.to("cpu")

    image = _PIPELINE(
        prompt=prompt,
        num_inference_steps=settings.local_image_steps,
        width=settings.local_image_width,
        height=settings.local_image_height,
    ).images[0]
    image.save(path, "PNG")


def _generate_huggingface(prompt: str, path: Path) -> None:
    settings = get_settings()
    if not settings.hf_api_key:
        raise RuntimeError("HF_API_KEY is required when IMAGE_PROVIDER=huggingface.")
    from huggingface_hub import InferenceClient

    client = InferenceClient(api_key=settings.hf_api_key)
    image = client.text_to_image(prompt, model=settings.hf_image_model)
    image.save(path, "PNG")


def generate_image(prompt: str, panel_number: int) -> str:
    settings = get_settings()
    path = _output_path(panel_number, prompt)

    if settings.demo_mode or settings.image_provider == "placeholder":
        return _placeholder_image(prompt, panel_number, path)
    if settings.image_provider == "huggingface":
        _generate_huggingface(prompt, path)
    elif settings.image_provider == "diffusers":
        _generate_diffusers(prompt, path)
    else:
        raise RuntimeError(f"Unsupported IMAGE_PROVIDER: {settings.image_provider}")

    return f"/static/panels/{path.name}"
