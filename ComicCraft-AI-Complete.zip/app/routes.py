from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from .config import get_settings
from .models import PromptRequest
from .services import create_comic
from .image_generator import generate_image

router = APIRouter()
templates = Jinja2Templates(directory=str(get_settings().template_dir))


def _error_message(exc: Exception) -> str:
    if isinstance(exc, RuntimeError):
        return str(exc)
    return f"Comic generation failed: {exc}"


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})


@router.post("/generate", response_class=HTMLResponse)
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        payload = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        result = create_comic(payload)
        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={"layout": result["panels"], "pdf_path": result["pdf_path"]},
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"error": _error_message(exc), "form": locals()},
            status_code=500,
        )


@router.post("/generate-comic/json")
async def generate_comic_json(payload: PromptRequest):
    try:
        result = create_comic(payload)
        return {"success": True, **result}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=_error_message(exc)) from exc


@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf_path: str = "/static/exports/comic.pdf"):
    return templates.TemplateResponse(
        request=request,
        name="export_success.html",
        context={"pdf_path": pdf_path},
    )


@router.get("/test-image")
async def test_image(prompt: str = "a brave fox in an enchanted forest, comic book art"):
    try:
        path = generate_image(prompt, 0)
        return JSONResponse({"success": True, "image_path": path})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=_error_message(exc)) from exc
