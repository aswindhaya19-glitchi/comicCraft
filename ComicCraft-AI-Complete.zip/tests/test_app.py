import os

os.environ["DEMO_MODE"] = "true"
os.environ["IMAGE_PROVIDER"] = "placeholder"

from fastapi.testclient import TestClient

from app.main import app
from app.layout_builder import build_comic_layout
from app.models import ComicOutline, ComicStory


def test_health():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_homepage():
    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    assert "ComicCraft" in response.text


def test_layout_builder():
    outline = ComicOutline(
        panels=[
            {"panel_number": i, "title": f"P{i}", "scene_description": "Scene", "image_prompt": "Prompt"}
            for i in range(1, 6)
        ]
    )
    story = ComicStory(
        panels=[
            {"panel_number": i, "caption": "C", "narration": "N", "dialogue": "D"}
            for i in range(1, 6)
        ]
    )
    result = build_comic_layout(outline, story, [f"/static/panels/{i}.png" for i in range(1, 6)])
    assert len(result) == 5
    assert result[0]["title"] == "P1"
